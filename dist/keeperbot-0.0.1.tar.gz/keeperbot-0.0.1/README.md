# KeeperBot
Assistant bot. Allows you to store contact book, expense book and additional related information.


## Module Build

Before building and installing the module using the command `pip list | grep wheel`, make sure that `wheel` is installed on your system.

Next, perform the build:

```
cd root KeeperBot project folder
python setup.py sdist bdist_wheel
pip install .
```
or install your package in editable mode
```
pip install -e .
```
## Generating Dependency List

- Creating the list: `pip freeze > requirements.txt`
- Installing dependencies: `pip install -r requirements.txt`
